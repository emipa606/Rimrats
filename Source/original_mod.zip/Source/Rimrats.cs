﻿using System.Collections.Generic;

using Verse;
using RimWorld;
using Verse.AI;

namespace Rimrats
{
    public class JobGiver_Curiosity : ThinkNode_JobGiver
    {
        public float searchRadius = 99999f;
        protected override Job TryGiveJob(Pawn pawn)
        {
            List<Building> allBuildings = pawn.Map.listerBuildings.allBuildingsColonist;
            List<Building> allBuildingsPowered = new List<Building>();

            if (allBuildings.Count > 0)
            {
                for (int i = 0; i < allBuildings.Count; i++)
                {
                    if (allBuildings[i].TransmitsPowerNow)
                    {
                        allBuildingsPowered.Add(allBuildings[i]);
                    }
                }

                if (allBuildingsPowered.Count > 0)
                {
                    float num2 = searchRadius * searchRadius;
                    for (int i = 0; i < allBuildingsPowered.Count; i++)
                    {
                        Building building = allBuildingsPowered[UnityEngine.Random.Range(0, allBuildingsPowered.Count)];

                        if (RimratBuildingTrashUtility.IsGoodTrashTargetFor(building, pawn))
                        {
                            if (searchRadius >= 9999f || (building.Position - pawn.Position).LengthHorizontalSquared <= num2)
                            {
                                return RimratBuildingTrashUtility.AttackJobOnFor(building, pawn);
                            }
                        }
                    }
                }
            }

            return null;
        }
    }

    public class ThinkNode_ConditionalRimrat : ThinkNode_Conditional
    {
        int curious = UnityEngine.Random.Range(1, 1000);

        public override ThinkNode DeepCopy(bool resolve = true)
        {
            ThinkNode_ConditionalRimrat thinkNode_ConditionalRimrat = (ThinkNode_ConditionalRimrat)base.DeepCopy();
            thinkNode_ConditionalRimrat.curious = curious;
            return thinkNode_ConditionalRimrat;
        }

        protected override bool Satisfied(Pawn pawn)
        {
            return Rand.Value < curious;
        }
    }

    public static class RimratBuildingTrashUtility
    {
        private const int AttackJobTimeLimit = 1000;
        public static bool IsGoodTrashTargetFor(Building b, Pawn pawn)
        {
            return pawn.CanReach(b, PathEndMode.Touch, Danger.Deadly, false, TraverseMode.ByPawn);
        }

        public static Job AttackJobOnFor(Building b, Pawn pawn)
        {
            Job job = new Job(JobDefOf.AttackMelee, b);
            int timeLimit = UnityEngine.Random.Range(300, 3000);
            job.expiryInterval = timeLimit;
            return job;
        }
    }
}
